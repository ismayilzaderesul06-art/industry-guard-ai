# INDUSTRY GUARD AI

**Autonomous Industrial Intelligence Platform**  
*Predict. Prevent. Optimize.*

Industry Guard AI is a hackathon MVP concept for industrial condition monitoring, predictive-maintenance workflows, energy-use analysis, and AI-assisted operational decision support.

> **Current implementation status:** this repository contains a browser-based interactive demonstration. The dashboard uses illustrative, hard-coded demo values and a scripted scenario. The five named agents are currently represented as a simulated workflow; they are **not yet independent AI models or autonomous agents**. No real equipment, sensors, plant network, or production database is connected.

## Problem

Unexpected equipment faults and inefficient energy use can interrupt production, increase maintenance costs, and make operational planning harder. Industrial teams need timely visibility into equipment condition and clear, explainable maintenance priorities.

## Proposed solution

The proposed platform is designed around a coordinated workflow:

1. **Monitor AI** — reviews incoming equipment measurements and flags unusual values.
2. **Predict AI** — estimates equipment risk using validated historical data and a predictive model.
3. **Energy AI** — analyzes energy consumption and identifies potential inefficiencies.
4. **Maintenance AI** — prepares prioritized inspection and maintenance suggestions.
5. **Decision AI** — consolidates findings into an explainable decision-support summary.

In the current demo, these roles are demonstrated through a scripted scenario. Real model inference and agent-to-agent orchestration are planned extensions.

## Current MVP features

- Responsive, dark-themed industrial dashboard.
- Example equipment status cards for motors, a pump, and a transformer.
- Illustrative energy-consumption chart.
- Five-agent workflow overview.
- Button-driven equipment anomaly demonstration.
- Activity log and maintenance recommendation panel.
- No build tools or installation required.

## Run locally

1. Download or clone this repository.
2. Open `index.html` in a modern browser.
3. Select **Ssenarini işə sal** to run the demonstration scenario.
4. Select **Sıfırla** to return the demo to its initial state.

The demo is a static front-end application and currently requires no API key or backend server.

## Demo data

`data/sample_equipment_readings.csv` contains illustrative sample readings for demonstration and future development. These values are synthetic and must not be interpreted as measurements from a real facility.

## Architecture and roadmap

See [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) for the proposed system architecture and development stages.

Planned next steps:

- Import and validate CSV equipment data in the application.
- Add unit-aware threshold configuration and transparent anomaly rules.
- Train and evaluate a predictive-maintenance model on appropriately sourced, labeled data.
- Integrate an LLM-backed assistant with clearly scoped tools and human approval.
- Implement agent orchestration, traceable outputs, and audit logs.
- Add authorized IoT/SCADA data connectors and security controls before any operational deployment.

## Technology

- HTML5
- CSS3
- Vanilla JavaScript
- SVG for the dashboard chart
- CSV for example equipment data

## Safety and limitations

This repository is a hackathon demonstration, not a certified industrial product or control system. It does not diagnose real equipment, guarantee failure prediction, or issue control commands. Do not use its outputs to make safety-critical, maintenance, or operational decisions. Any real deployment would require domain-expert validation, representative data, cybersecurity review, testing, and appropriate human authorization.

## Contribution

Issues and suggestions are welcome. Please describe reproducible bugs, the expected behavior, and relevant screenshots or sample data. Do not upload confidential industrial data, credentials, API keys, or personal information.

## License

This project is released under the MIT License. See [LICENSE](LICENSE).
