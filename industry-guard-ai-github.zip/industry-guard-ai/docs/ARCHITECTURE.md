# Architecture and development plan

## Current demo architecture

```text
Browser
  |
  +-- index.html
       +-- HTML dashboard components
       +-- CSS responsive layout
       +-- JavaScript scripted demo workflow
       +-- SVG illustrative energy chart

Supporting example data
  +-- data/sample_equipment_readings.csv
```

The current implementation is front-end only. Dashboard values and the demonstration scenario are embedded in `index.html`; the CSV file is an example dataset for future integration and is not currently loaded by the application.

## Proposed target architecture

```text
Authorized equipment data / CSV / IoT gateway
                    |
             Data validation layer
                    |
          Time-series data storage
                    |
        Monitoring and anomaly service
                    |
        Agent orchestration service
          /       |       |       \
    Predict   Energy  Maintenance  Context
          \       |       |       /
            Decision-support agent
                    |
        Human-reviewed recommendations
                    |
             Web dashboard + audit log
```

## Agent responsibilities

| Agent | Inputs | Intended output |
|---|---|---|
| Monitor | Temperature, vibration, load, current, voltage | Data-quality checks and anomaly flags |
| Predict | Validated historical and current readings, labels | Evaluated risk estimate with uncertainty |
| Energy | Power, energy, operating schedule, production context | Consumption analysis and potential savings hypotheses |
| Maintenance | Alerts, asset criticality, maintenance history | Prioritized inspection task proposal |
| Decision | Outputs from the other services and operating constraints | Explainable summary for human review |

## Development stages

1. **MVP (current):** static dashboard and scripted demonstration.
2. **Data ingestion:** CSV upload, schema validation, missing-value handling, units, and timestamps.
3. **Analytics:** transparent threshold rules and baseline comparisons.
4. **Predictive model:** train/test split by time, leakage checks, suitable metrics, calibration, and validation on representative labeled data.
5. **AI assistant and orchestration:** connect an LLM through a secure backend; define tool permissions, structured outputs, timeouts, and human approval.
6. **Industrial integration:** authorized read-only connectors first, cybersecurity assessment, auditability, and safety review.

## Evaluation criteria for a future predictive model

Use representative labeled equipment histories. Report the data source, sample size, prediction horizon, train/validation/test split, class balance, precision, recall, F1, PR-AUC where appropriate, false-alarm rate, and limitations. Do not report fabricated model accuracy or claim validated prediction until these experiments have been run.

## Safety principles

- Default to read-only data access.
- Never allow an LLM to directly control industrial equipment.
- Require qualified human review for maintenance and operational actions.
- Keep logs of inputs, model versions, recommendations, and approvals.
- Protect credentials and sensitive plant data; never commit secrets to Git.
